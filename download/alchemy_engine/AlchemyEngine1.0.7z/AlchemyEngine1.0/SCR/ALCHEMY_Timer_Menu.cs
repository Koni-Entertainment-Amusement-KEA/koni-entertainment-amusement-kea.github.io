using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.TextCore.Text;
using UnityEngine.UI;

public class ALCHEMY_Timer_Menu : MonoBehaviour
{
    public float timeRemaining = 30;
    public AudioSource warningSound;

    private void Start()
    {
        StartCoroutine(WaitForLowTime());
    }

    void Update()
    {
        if (timeRemaining > 0)
        {
            timeRemaining -= Time.deltaTime;

            GetComponent<Text>().text = Mathf.Round(timeRemaining).ToString();
        }

        if (timeRemaining < 10)
        {
            GetComponent<Text>().color = new Color(255, 0, 0);
            
        }

        if (timeRemaining < 0)
        {
            timeRemaining = 0;
            StopAllCoroutines(); // Cut it out!!!!!!!!!!!!!!!!!!!!!!!!!!!
        }
    }

    IEnumerator WaitForLowTime() // funny ass names but you gotta do what you gotta do
    {
        yield return new WaitForSeconds(10.5f);
        warningSound.Play();
        yield return new WaitForSeconds(1);
        warningSound.Play();
        yield return new WaitForSeconds(1);
        warningSound.Play();
        yield return new WaitForSeconds(1);
        warningSound.Play();
        yield return new WaitForSeconds(1);
        warningSound.Play();
        yield return new WaitForSeconds(1);
        warningSound.Play();
        yield return new WaitForSeconds(1);
        warningSound.Play();
        yield return new WaitForSeconds(1);
        warningSound.Play();
        yield return new WaitForSeconds(1);
        warningSound.Play();
        yield return new WaitForSeconds(1);
        warningSound.Play();
        yield return new WaitForSeconds(1); // I need to go to sleep its 1 am wtf
    }
}
