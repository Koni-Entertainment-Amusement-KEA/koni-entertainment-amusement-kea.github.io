using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ALCHEMY_Timer : MonoBehaviour
{
    public float timeRemaining = 10; // this value determines how much time u got at the start

    void Update()
    {
        if (timeRemaining > 0)
        {
            timeRemaining -= Time.deltaTime;
            GetComponent<Text>().text = Mathf.Round(timeRemaining).ToString(); // this HAS to be the legacy text
                                                                               // otherwise it won't work for some reason

            // your function goes here (make sure u make a copy of this script)
        }

        // if (timeRemaining < 10)
        //{
        //  code also goes here
        //}

        // if (timeRemaining < 0)
        //{
        //  code also goes here
        //}
    }
}
